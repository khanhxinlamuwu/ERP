from odoo import models, fields, api

class ApplicantTraining(models.Model):
    _name = 'applicant.training'
    _description = 'Applicant Training'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Training Name', required=True)
    applicant_id = fields.Many2one(
        'hr.applicant', 
        string='Applicant', 
        required=True
    )
    partner_name = fields.Char(
        related='applicant_id.partner_name', 
        string='Applicant Name', 
        readonly=True
    )
    start_date = fields.Date(
        string='Training Start Date', 
        required=True
    )
    end_date = fields.Date(
        string='Training End Date', 
        required=True
    )
    description = fields.Text(
        string='Training Description'
    )
    supervisor_id = fields.Many2one(
        'hr.employee', 
        string='Supervisor', 
        required=True
    )
    stage_id = fields.Many2one(
        'applicant.training.stage', 
        string='Training Stage', 
        tracking=True,
        group_expand='_read_group_stage_ids'
    )
    
    @api.model
    def _read_group_stage_ids(self, stages, domain, order):
        # Ensures all stages are shown in group_expand
        return self.env['applicant.training.stage'].search([], order=order)

    _sql_constraints = [
        ('date_check', 
         'CHECK(start_date <= end_date)', 
         'End date must be after start date!')
    ]

class ApplicantTrainingStage(models.Model):
    _name = 'applicant.training.stage'
    _description = 'Applicant Training Stage'
    _order = 'sequence, id'

    name = fields.Char(string='Stage Name', required=True, translate=True)
    sequence = fields.Integer(default=10)
    fold = fields.Boolean(
        string='Folded in Kanban', 
        help='This stage is folded in the kanban view when there are no records in that stage.'
    )
