{
    'name': 'Applicant Training Management',
    'version': '1.0',
    'category': 'Human Resources',
    'summary': 'Manage Training for Job Applicants',
    'description': 'Track and manage training for job applicants',
    'author': 'Your Company',
    'depends': ['hr_recruitment', 'hr'],
    'data': [
        'security/ir.model.access.csv',
        'views/applicant_training_views.xml',
    ],
    'installable': True,
    'application': True,
}